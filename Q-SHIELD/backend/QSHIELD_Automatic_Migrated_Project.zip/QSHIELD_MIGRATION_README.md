# test_sample_migration – Q-SHIELD Migration Output

Migration mode: automatic

## Contents
- Original project structure preserved where possible.
- `QSHIELD_MIGRATION_REPORT.json` contains detected findings and applied changes.
- This README describes validation requirements.

## Important
This output is a migration starting point, not a guarantee of a production-ready
PQC application. Review all manual actions in the JSON report. Run the project's
own tests, build, interoperability checks and security review before deployment.

Q-SHIELD does not execute uploaded project code.
