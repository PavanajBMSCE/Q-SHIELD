# Q-SHIELD PQC migration output

This package contains a narrowly-scoped ML-KEM-768 + HKDF-SHA256 + AES-256-GCM demonstration migration. The demo verifies ML-KEM shared-secret equality and AES-GCM plaintext round-trip. AES-GCM is conventional authenticated encryption, not a PQC algorithm. Review QSHIELD_PQC_MIGRATION_REPORT.json. Install a compatible cryptography release (>=50.0.0), run the demo in an isolated test environment, and complete protocol, key-management, interoperability and security reviews before production use.
